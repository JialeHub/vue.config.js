<template>
  <div id="appFooter">
      Footer
  </div>
</template>

<script>
  export default {
    name: "appFooter",
    data() {
      return {}
    }
  }
</script>

<style lang="scss">

</style>
