import Vue from "vue";

/**
 * @description 按需引入Element-UI组件
 * */
import {
  Upload,
} from "element-ui";

Vue.component("ElUpload", Upload);

