<template>
  <div id="log">
    log
  </div>
</template>

<script>

  export default {
    name: 'log',
    components: {},
    methods: {

    }
  }
</script>

<style lang="scss">
  #log {
  }
</style>
