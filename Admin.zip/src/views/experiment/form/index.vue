<template>
  <div id="form" style="width: 100%;">

  </div>
</template>

<script>

  export default {
    name: 'form',
    components: {},
    data() {
      return {
        src: '',
      };
    },
    mounted() {

    },
    methods: {

    }
  }
</script>

<style lang="scss">
  #form {
  }
</style>
