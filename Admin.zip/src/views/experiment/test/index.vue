<template>
  <div id="test">

  </div>
</template>

<script>
export default {
  name: 'test',
  data() {
    return {
      data: null,
    }
  },
  mounted() {

  },
  methods: {

  }
}
</script>

<style lang="scss">
#pluginDemo {

}
</style>
